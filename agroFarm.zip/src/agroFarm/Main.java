package agroFarm;

public class Main {
	public static void main(String args[]){
		DbConnection.connect();
		Login lg=new Login();
	}

}
