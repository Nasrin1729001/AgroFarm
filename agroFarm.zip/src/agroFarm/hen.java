package agroFarm;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import com.toedter.calendar.JDateChooser;



public class hen extends JPanel{

	JPanel panelCenter= new JPanel();
	JPanel panelEast =new JPanel();

	JPanel panelCenterNorth=new JPanel();
	JPanel panelCenterCenter=new JPanel();
	
	JPanel panelEastSouth=new JPanel();
	JPanel panelEastCenter=new JPanel();
	
	JLabel lblSearch=new JLabel("Search");
	SuggestText cmbSearch=new SuggestText();


	JButton btnAdd=new JButton("Add");
	JButton btnRefresh=new JButton("Refresh");
	JButton btnDelete=new JButton("Delete");

	JLabel lblUserName=new JLabel("User Name");
	String ara[]={"","nasrin","prima"};
	JComboBox cmbUserName=new JComboBox(ara);

	JLabel lblDate=new JLabel("Date");
	JDateChooser txtDate= new JDateChooser();

	JLabel lblQtyOfSell=new JLabel("Qty Of Sell");
	JTextField txtQtyOfSell=new JTextField(50);
	
	JLabel lblQtyOfEggSell=new JLabel("Qty Of Egg Sell");
	JTextField txtQtyOfEggSell=new JTextField(50);

	JLabel lblAmount=new JLabel("Amount");
	JTextField txtAmount=new JTextField(50);
	
	SimpleDateFormat dateFormatSql= new SimpleDateFormat("yyyy-MM-dd");


	public hen(){
		//setBackground(Color.blue);
		setPreferredSize(new Dimension(1150,730));
		setLayout(new GridLayout(1, 0,10,10));
		add(panelCenter);
		add(panelEast);
		panelCenterWork();
		panelEastWork();

	}

	private void panelEastWork(){

		panelEast.setBorder(BorderFactory.createRaisedSoftBevelBorder());
		panelEast.setLayout(new BorderLayout());
		panelEast.add(panelEastSouth,BorderLayout.SOUTH);
		panelEast.add(panelEastCenter,BorderLayout.CENTER);

		panelEastSouthWork();
		panelEastCenterWork();
	}

	private void panelEastCenterWork() {
		panelEastCenter.setBorder(BorderFactory.createRaisedSoftBevelBorder());
		panelEastCenter.add(lblSearch);
		panelEastCenter.add(cmbSearch.cmbSuggest);
		
		cmbSearch.cmbSuggest.setPreferredSize(new Dimension(150,25));
		FlowLayout flow = new FlowLayout();
		panelEastCenter.setLayout(flow);
	}

	private void panelEastSouthWork() {
		panelEastSouth.setBorder(BorderFactory.createRaisedSoftBevelBorder());
		panelEastSouth.setPreferredSize(new Dimension(0,650));
		
	}
	private void panelCenterWork() {
		panelCenter.setBorder(BorderFactory.createLoweredSoftBevelBorder());
		panelCenter.setLayout(new BorderLayout());
		panelCenter.add(panelCenterNorth,BorderLayout.NORTH);
		panelCenter.add(panelCenterCenter,BorderLayout.CENTER);

		panelCenterNorthWork();
		panelCenterCenterWork();


	}

	private void panelCenterCenterWork() {
		panelCenterCenter.setBorder(BorderFactory.createRaisedSoftBevelBorder());
		FlowLayout flow=new FlowLayout();
		panelCenterCenter.setLayout(flow);
		panelCenterCenter.add(btnAdd);
		panelCenterCenter.add(btnRefresh);
		panelCenterCenter.add(btnDelete);
	}

	private void panelCenterNorthWork() {
		panelCenterNorth.setBorder(BorderFactory.createRaisedSoftBevelBorder());
		panelCenterNorth.setPreferredSize(new Dimension(0,650));
		GridBagConstraints c= new GridBagConstraints();
		panelCenterNorth.setLayout(new GridBagLayout());
        
		
		c.gridx=0;
		c.gridy=0;
		c.fill=GridBagConstraints.BOTH;
		c.insets=new Insets(5,5,5,5);
		panelCenterNorth.add(lblUserName,c);

		c.gridx=1;
		c.gridy=0;
		c.fill=GridBagConstraints.BOTH;
		c.insets=new Insets(5,5,5,5);
		panelCenterNorth.add(cmbUserName,c);
		

		c.gridx=0;
		c.gridy=1;
		c.fill=GridBagConstraints.BOTH;
		c.insets=new Insets(5, 5, 5, 5);
		panelCenterNorth.add(lblDate,c);

		c.gridx=1;
		c.gridy=1;
		c.fill=GridBagConstraints.BOTH;
		c.insets=new Insets(5, 5, 5, 5);
		panelCenterNorth.add(txtDate,c);
		txtDate.setDateFormatString("dd-MM-yyyy");
		txtDate.setDate(new Date());


		c.gridx=0;
		c.gridy=2;
		c.fill=GridBagConstraints.BOTH;
		c.insets=new Insets(5, 5, 5, 5);
		panelCenterNorth.add(lblQtyOfSell,c);

		c.gridx=1;
		c.gridy=2;
		c.fill=GridBagConstraints.BOTH;
		c.insets=new Insets(5, 5, 5, 5);
		panelCenterNorth.add(txtQtyOfSell,c);

     	c.gridx=0;
		c.gridy=3;
		c.fill=GridBagConstraints.BOTH;
		c.insets=new Insets(5, 5, 5, 5);
		panelCenterNorth.add(lblQtyOfEggSell,c);

		c.gridx=1;
		c.gridy=3;
		c.fill=GridBagConstraints.BOTH;
		c.insets=new Insets(5, 5, 5, 5);
		panelCenterNorth.add(txtQtyOfEggSell,c);

		c.gridx=0;
		c.gridy=4;
		c.fill=GridBagConstraints.BOTH;
		c.insets=new Insets(5, 5, 5, 5);
		panelCenterNorth.add(lblAmount,c);

		c.gridx=1;
		c.gridy=4;
		c.fill=GridBagConstraints.BOTH;
		c.insets=new Insets(5, 5, 5, 5);
		panelCenterNorth.add(txtAmount,c);
		

		

	
		
	}

}
