package agroFarm;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class workingPanel extends JPanel{
	JPanel panelWest=new JPanel();
	JPanel panelCenter=new JPanel();

	JButton btnCow=new JButton(new ImageIcon("Images/cow.jpg"));
	JLabel  lblCow=new JLabel("Cow");

	JButton btnDuck=new JButton(new ImageIcon("Images/duck.png"));
	JLabel  lblDuck=new JLabel("Duck");

	JButton btnHen=new JButton(new ImageIcon("Images/hen.jpg"));
	JLabel  lblHen=new JLabel("Hen");

	JPanel panelCow=new JPanel();
	JPanel panelDuck=new JPanel();
	JPanel panelHen=new JPanel();

	cow cow=new cow();
	duck duck=new duck();
	hen hen=new hen();

	public workingPanel(){
		//setBackground(Color.green);
		setLayout(new BorderLayout());
		add(panelWest,BorderLayout.WEST);
		add(panelCenter,BorderLayout.CENTER);
		panelCenterWork();
		panelWestWork();
		btnAction();

	}
	private void sidePanelTrueFalse(){
		panelCow.setVisible(false);
		panelDuck.setVisible(false);
		panelHen.setVisible(false);
	}

	private void btnAction() {
		btnHen.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0){
				sidePanelTrueFalse();
				panelHen.setVisible(true);

			}
		});
		btnDuck.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0){
				sidePanelTrueFalse();
				panelDuck.setVisible(true);
			}
		});

		btnCow.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0){
				sidePanelTrueFalse();
				panelCow.setVisible(true);
			}
		});

	}

	private void panelWestWork() {
		panelWest.setBorder(BorderFactory.createLoweredSoftBevelBorder());
		panelWest.setPreferredSize(new Dimension(200,0));
		GridBagLayout grid= new GridBagLayout();
		GridBagConstraints c= new GridBagConstraints();
		panelWest.setLayout(grid);

		c.gridx = 0;
		c.gridy = 0;
		c.fill = GridBagConstraints.BOTH;
		c.insets = new Insets(5,5,5,5);
		panelWest.add(btnCow,c);

		c.gridx = 0;
		c.gridy = 1;
		c.fill = GridBagConstraints.BOTH;
		c.insets = new Insets(5,5,5,5);
		panelWest.add(lblCow,c);

		c.gridx = 0;
		c.gridy = 2;
		c.fill = GridBagConstraints.BOTH;
		c.insets = new Insets(5,5,5,5);
		panelWest.add(btnDuck,c);

		c.gridx = 0;
		c.gridy = 3;
		c.fill = GridBagConstraints.BOTH;
		c.insets = new Insets(5,5,5,5);
		panelWest.add(lblDuck,c);


		c.gridx = 0;
		c.gridy = 4;
		c.fill = GridBagConstraints.BOTH;
		c.insets = new Insets(5,5,5,5);
		panelWest.add(btnHen,c);

		c.gridx = 0;
		c.gridy = 5;
		c.fill = GridBagConstraints.BOTH;
		c.insets = new Insets(5,5,5,5);
		panelWest.add(lblHen,c);



	}

	private void panelCenterWork() {
		panelCenter.setBorder(BorderFactory.createRaisedSoftBevelBorder());
		FlowLayout flow=new FlowLayout();
		panelCenter.setLayout(flow);
		panelCenter.add(panelDuck);
		panelCenter.add(panelHen);
		panelCenter.add(panelCow);
		panelPatientWork();
		panelDonorWork();
		panelChangetatusWork();
		panelCenter.add(btnCow);
		panelCenter.add(btnDuck);
		panelCenter.add(btnHen);
	}
	private void panelChangetatusWork() {
		panelCow.add(cow);

	}
	private void panelPatientWork() {
		//panelPatient.setBackground(Color.blue);
		panelDuck.add(duck);
	}
	private void panelDonorWork() {
		//panelDonor.setBackground(Color.magenta);

		panelHen.add(hen);

	}

}
