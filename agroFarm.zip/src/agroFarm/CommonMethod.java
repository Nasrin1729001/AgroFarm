package agroFarm;
import java.sql.ResultSet;

import javax.swing.JOptionPane;

public class CommonMethod {
	public static boolean checkConfirmation(String caption){
		int a= JOptionPane.showConfirmDialog(null,caption,"Confirmation..",JOptionPane.YES_NO_OPTION);
		if(a==JOptionPane.YES_OPTION){
			return true;
		}
		return false;
		}
	public static boolean isExistName(String query){
		try{
			DbConnection.connect();
			ResultSet rs=DbConnection.sta.executeQuery(query);
			if(rs.next()){
				JOptionPane.showMessageDialog(null,"already exist");
			 return false;
			}
			DbConnection.con.close();
		}
		catch(Exception exp){
			JOptionPane.showMessageDialog(null, exp);
		}
		return true;
	}
	public static boolean insertData(String sql){
		try{
			DbConnection.connect();
			DbConnection.sta.executeUpdate(sql);
			DbConnection.con.close();
			return true;
		}
		catch(Exception exp){
			JOptionPane.showMessageDialog(null, exp);
		}
		return false;
	}
}
