package agroFarm;



import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;


public class Login extends JFrame{
	JPanel panelLogin=new JPanel();
	JPanel panelNorth=new JPanel();
	JPanel panelCenter=new JPanel();
	
	JLabel lblBackground=new JLabel(new ImageIcon("Images/farm.jpg"));
	JButton btnLogin =new JButton("Login",new ImageIcon("Images/Ok-icon - Copy.png"));
	JButton btnExit =new JButton("Exit",new ImageIcon("Images/o3.png"));
	JLabel lblUsername= new JLabel("Username:");
	JTextField txtUsername=new JTextField(20);
    JLabel lblPassword= new JLabel("Password:");
	JTextField txtPassword=new JTextField(20);
	
	Dimension screen= Toolkit.getDefaultToolkit().getScreenSize();
 public Login(){
	 init();
	 cmp();
	 btnAction();
 }
 private void loginAction() {

		panelLogin.setVisible(false);
		workingPanel wp = new workingPanel();
		add(wp);
		wp.setVisible(true);
		setSize(screen);
        setLocationRelativeTo(null);
	}
	private void btnAction() {
		btnLogin.addActionListener(new ActionListener() {			
			public void actionPerformed(ActionEvent arg0) {
				loginAction();
			}
		});
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//dispose();
				System.exit(0);
			}
		});
	}

private void cmp() {
	add(panelLogin);
	panelLogin.setLayout(new BorderLayout());
	panelLogin.add(panelNorth,BorderLayout.NORTH);
	panelLogin.add(panelCenter,BorderLayout.CENTER);
	panelNorthWork();
	panelCenterWork();
	
	//panelLogin. setBackground(Color.blue);
	
}

private void panelCenterWork() {
   panelCenter.setBorder(BorderFactory.createLoweredSoftBevelBorder());
    panelCenter.setLayout(new GridLayout());
     panelCenter.add(btnLogin);
     panelCenter.add(btnExit);
     
	
}

private void panelNorthWork() {
	panelNorth.setBorder(BorderFactory.createEmptyBorder());
	panelNorth.setPreferredSize(new Dimension(0,230));
	panelNorth.add(lblBackground);
	GridBagLayout grid= new GridBagLayout();
	GridBagConstraints c= new GridBagConstraints();
	lblBackground.setLayout(grid);

	c.gridx = 0;
	c.gridy = 0;
	c.fill = GridBagConstraints.BOTH;
	c.insets = new Insets(5,5,5,5);
	lblBackground.add(lblUsername,c);
	lblUsername.setForeground(Color.BLACK);

	c.gridx = 1;
	c.gridy = 0;
	c.fill = GridBagConstraints.BOTH;
	c.insets = new Insets(5,5,5,5);
	lblBackground.add(txtUsername,c);

	c.gridx = 0;
	c.gridy = 1;
	c.fill = GridBagConstraints.BOTH;
	c.insets = new Insets(5,5,5,5);
	lblBackground.add(lblPassword,c);
	
	c.gridx = 1;
	c.gridy = 1;
	c.fill = GridBagConstraints.BOTH;
	c.insets = new Insets(5,5,5,5);
	lblBackground.add(txtPassword,c);


}

private void init() {
	setSize(400,300);
	setVisible(true);
	setLocationRelativeTo(null);
	setTitle("AgroFarm PROJECT");
	setResizable(false);
	
}
}
